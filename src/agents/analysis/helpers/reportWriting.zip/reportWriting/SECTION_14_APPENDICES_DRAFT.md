# 14) Appendices

## Appendix A — Full list of tools (MCP)

This list is extracted from the two MCP servers configured for the analysis pipeline (`analysis_server_config` and `data_process_server_config`).

### A.1 analysis server tools (`src/mcp_servers/analysis/fastmcp_server.py`)

- load_and_analyze_csv — Load a CSV file and provide a detailed summary of its structure and contents.
- perform_advanced_eda_on_csv — Perform comprehensive exploratory data analysis (EDA) on a CSV dataset.
- analyze_csv_patterns — Detect patterns, anomalies, and outliers in dataset columns using statistical methods.
- handle_missing_values — Clean missing values in a CSV file using flexible imputation or removal strategies.
- handle_outliers — Detect and handle outliers in a numeric column using the IQR method.
- perform_t_test — Perform statistical t-test to compare means between two groups.
- perform_anova — Perform one-way ANOVA to compare means across multiple groups (3+).
- generate_plot — Generate and save statistical and temporal plots from a CSV dataset.
- generate_correlation_heatmap — Generate a correlation heatmap for numeric columns with sensible defaults and guardrails.
- train_classification_model — Train and evaluate a classification model on tabular data.
- assess_data_quality — Perform comprehensive data quality assessment on a CSV dataset.
- perform_automated_statistical_tests — Automatically perform appropriate statistical tests based on data types and distributions.
- analyze_temporal_patterns — Perform comprehensive temporal pattern analysis with visualizations.
- analyze_text_content — Analyze text column content to identify patterns and extraction opportunities.
- extract_structured_data_from_text — Extract structured data from unstructured text columns using intelligent pattern recognition.
- merge_text_extracted_data — Merge text-extracted data with existing structured columns intelligently.

### A.2 data processing server tools (`src/mcp_servers/analysis/data_processing_server.py`)

- llm_message_parser — Parse any message format using LLM intelligence.
- llm_dataset_detector — Detect datasets in any message format using LLM intelligence.
- llm_instruction_extractor — Extract analysis instructions from any format using LLM intelligence.
- clean_dataset — Clean a dataset by removing duplicates and handling missing values.
- transform_data_types — Transform data types of specific columns in a dataset.
- validate_data_quality — Perform comprehensive data quality validation on a dataset.
- export_processed_data — Export processed data to various formats.
- get_server_info — Get information about this data processing server.

## Appendix B — Example A2A streaming events

The analysis A2A service emits updates as `DataPart` payloads. Below are representative shapes used for (1) status updates and (2) artifact updates.

### B.1 Status update (representative)

```json
{
  "agent_task_id": "<task-id>",
  "content": "...accumulated streaming text...",
  "tool_call_chunks": [],
  "current_action": "Working in execute_step",
  "current_node": "execute_step"
}
```

### B.2 Artifact update (representative)

```json
{
  "agent_task_id": "<task-id>",
  "content": "output/temporal_plots/plot_001.png",
  "tool_calls": [],
  "current_action": "Artifact generated",
  "current_node": "execute_step"
}
```

## Appendix C — Selected code excerpts

Excerpts are kept short and limited to code referenced by the main report sections.

### C.1 Guardrail: path validation + forced output directory

From `src/agents/analysis/pipeline/security_guards.py`:

```python
def validate_and_resolve_path(
    raw_path: str,
    *,
    repo_root: Path,
    allowed_roots: Sequence[Path],
) -> Path:
    """Resolve a user/tool-supplied path and ensure it stays under an allowlisted root."""
    raw = str(raw_path).strip()
    if _has_parent_traversal(raw):
        raise GuardrailViolation(f"Path traversal is not allowed: {raw}", kind="path")

    p = Path(raw)
    if not p.is_absolute():
        p = (repo_root / p).resolve(strict=False)
    else:
        p = p.resolve(strict=False)

    for root in allowed_roots:
        if _is_under_root(p, root):
            return p

    raise GuardrailViolation(
        f"Path is outside allowed roots: {p}.",
        kind="path",
    )

# ...

# Output dir is forced under reports_path
for key in list(cleaned.keys()):
    if key in _PATH_KEYS_WRITE_DIR:
        cleaned[key] = str(self.forced_output_dir)
        warnings.append(f"Forced '{key}' to safe output dir")
```

### C.2 Guardrail enforcement: block + replan on violation

From `src/agents/analysis/pipeline/runner.py` (`execute_step`):

```python
if policy is not None:
    try:
        args, guard_warnings = policy.sanitize_args(str(tool_name), dict(args), tool_obj=tool)
    except GuardrailViolation as gv:
        err_msg = f"Security policy blocked tool call '{tool_name}': {gv}"
        updates = {
            "tool_transcript": [{"tool": tool_name, "args": args, "result": err_msg, "status": "error"}],
            "telemetry": {"tool_calls": 1, "tool_errors": 1},
            "warnings": [err_msg],
        }
        try:
            updates["messages"] = [HumanMessage(content=err_msg + " Please replan using safe tools/paths.")]
        except Exception:
            pass
        return Command(update=updates, goto="planner")
```

### C.3 A2A streaming: throttled status updates + artifacts

From `src/agents/analysis/a2a_compliant_service.py` (stream forwarding):

```python
if throttle.should_emit(now_s=now_s, current_len=len(accumulator)):
    response_data = {
        "agent_task_id": str(context.task_id),
        "content": accumulator.get(),
        "tool_call_chunks": list(getattr(msg, "tool_call_chunks", []) or []),
        "current_action": _action_for_node(current_node or "analysis_pipeline"),
        "current_node": current_node or "analysis_pipeline",
    }
    if await SchemaValidator(A2AUpdaterStatusAdapter, response_data):
        status_part = Part(root=DataPart(data=response_data, kind="data"))
        await updater.update_status(
            TaskState.working,
            updater.new_agent_message(parts=[status_part]),
        )
```
