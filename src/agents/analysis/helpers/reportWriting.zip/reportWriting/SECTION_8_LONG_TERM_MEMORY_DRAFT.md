# 8) Long-Term Memory (Run History + Dataset Profiles)

This section describes how the analysis agent retains useful information across runs. The implementation deliberately does NOT attempt a full semantic memory system (vector store, embeddings, cross-dataset retrieval). Instead, it uses two pragmatic, file-backed mechanisms that are easy to inspect, easy to cap, and safe to operate in a local evaluation setting:

1) Run history metadata: compact per-dataset JSON records capturing the last N runs.
2) Persisted dataset profiles: a per-dataset schema/profile JSON snapshot used to avoid repeating dataset inspection.

These mechanisms are "long-term" in the operational sense: they survive process restarts because they are written to disk under the agent's configured report directory.

## 8.1 What Counts as "Memory" in This System (And What Does Not)

It is important to distinguish three different concepts that can be confused:

- LangGraph interrupt/resume state: required for HITL plan review. In this project it uses an in-memory checkpointer (`InMemorySaver`) keyed by `thread_id=contextId`. This enables pausing and resuming a single task, but it does not persist across server restarts.
- Pipeline working state (`AnalysisPipelineState`): the in-flight state during a single execution (plan, tool transcript, insights, artifacts). This is bounded via reducers and caps.
- Long-term memory (this section): file-backed run metadata and dataset profiles that are loaded at the start of new runs.

In other words: HITL resume correctness is achieved by LangGraph checkpointer + thread_id, while cross-run continuity is achieved by JSON files on disk.

## 8.2 Storage Location and Keys (On-Disk Contract)

Both run history and dataset profiles are stored under the analysis agent's reports directory:

- Base: `AgentConfig().reports_path` (defaults to `agent_system/src/agents/analysis/reportDemo/`)
- Memory directory: `<reports_path>/metadata/`

Within that directory, the files are keyed by a normalized dataset key derived from the dataset filename stem:

- Dataset key: `Path(dataset_path).stem.replace(' ', '_')`

This keying is intentionally simple and human-readable, but it implies a known limitation: two datasets with the same filename stem but different directories will collide.

If a dataset path is missing entirely, the memory store falls back to a generic dataset key ("generic"). This allows the system to persist a minimal record even when a client did not provide a resolvable dataset path, but it also means unrelated runs can co-mingle under the same generic file.

### 8.2.1 Run history file

- File pattern: `<dataset_key>.json`
- Contents: JSON list of run records, newest-first
- History cap: `DEFAULT_HISTORY_LIMIT=10` (older records are dropped)

### 8.2.2 Persisted dataset profile file

- File pattern: `<dataset_key>_profile.json`
- Contents: a JSON dict containing the dataset profile (at minimum includes `columns`)

### 8.2.3 One-time migration behavior

To preserve compatibility with earlier layouts, the memory store includes a best-effort migration:

- If legacy directory `src/agents/analysis/reportDemo/metadata/` exists
- And the configured metadata directory is empty
- Then `*.json` files are copied into the configured directory.

### 8.2.4 Legacy migration for dataset profiles

Dataset profiles have a second legacy-compatibility path: when loading `<dataset_key>_profile.json`, the pipeline will also check the legacy repository-relative location and copy it forward if found. This ensures older runs remain reusable after the reports directory layout changed.

## 8.2.5 Quick reference table

| Mechanism | Storage file | Read timing | Write timing | Primary purpose |
|---|---|---|---|---|
| Run history (RunMetadata list) | `<dataset_key>.json` | Ingress (`ingest_request`) | Finalization (`synthesis`/`persist_cleanup`) | Provide lightweight historical grounding + auditable evidence |
| Dataset profile (schema snapshot) | `<dataset_key>_profile.json` | Ingress (`ingest_request`) | Planning (`planner`) | Keep planning and tool args grounded in real columns |

## 8.3 Run History Schema (What Is Remembered)

Each run record is a structured summary (Pydantic dataclass `RunMetadata`) designed to be useful for planning and debugging without storing large raw tool outputs.

A run record includes the following fields:

- `dataset_path`: stored as a best-effort relative path for portability
- `instruction`: the user instruction for that run
- `findings_summary`: a compact summary of the run results (currently derived from the report text)
- `plan_summary`: short summary of the last few planned steps (tool + why)
- `artifacts`: artifact paths stored relative to `reports_path` when possible
- `issues`: errors extracted from `tool_transcript` entries with `status == 'error'`
- `warnings`, `errors`: merged/capped operational warnings/errors
- `telemetry`: clipped counters/diagnostics (bounded to avoid bloat)
- `hitl_plan_review`: optional dict capturing plan review decision/feedback/plan hash/plan steps
- `timestamp`: UTC ISO timestamp

Two implementation details matter for safety and operability:

- Clipping: nested values are clipped by depth and maximum lengths to keep the record small and prevent accidental persistence of huge outputs.
- Relative paths: dataset paths and artifact paths are stored relatively (best-effort) so that the metadata remains portable when the repo is moved.

## 8.4 Lifecycle: When Memory Is Loaded and When It Is Written

Long-term memory is used as early-run grounding and late-run persistence.

### 8.4.1 Load at ingress (`ingest_request`)

At the beginning of a run, the pipeline attempts to load history and a dataset profile when a `dataset_path` is present:

1) Load run history: `MemoryStore.load_history(dataset_path)`.
2) Build a concise "historical snippet" from the most recent record.
   - Includes: previous findings, any HITL plan review decision/feedback, reviewed plan steps, and a few known issues.
   - Snippet is capped (best-effort) to avoid prompt bloat.
3) Load the persisted dataset profile (`*_profile.json`) if it exists.
4) Store both into LangGraph state as:
   - `historical_snippet`
   - `preprocess_profile`

This makes history available to the planner prompt via the prompt factory: when `historical_snippet` exists, the planner prompt is prefixed with "Historical context".

### 8.4.2 Persist profile during planning (`planner`)

To keep planning grounded in real columns, the planner ensures a dataset profile exists:

- If `state.preprocess_profile` is already populated (e.g., loaded from disk), it reuses it.
- Otherwise, it builds a dataset inspection snapshot and persists it to `<dataset_key>_profile.json`.

This profile is then used to:

- Suggest columns when constructing tool argument hints.
- Auto-correct invalid column arguments in `execute_step`.

### 8.4.3 Append run metadata during finalization (`synthesis` / `persist_cleanup`)

After synthesis constructs the output envelope, the pipeline schedules a file-backed append:

1) `metadata = build_run_metadata(state, output.report_text)`.
2) `MemoryStore.schedule_append(metadata)`.
   - Writes newest-first.
   - Prunes to the last 10 records.
   - Uses async thread-based write when an event loop is present; falls back to synchronous write otherwise.
   - Uses a short timeout for async writes (`ASYNC_WRITE_TIMEOUT=5s`) so persistence cannot hang the service.

This append is designed to be best-effort and must not block or crash the pipeline if the filesystem write fails.

Optional maintenance: the store exposes a `prune()` method that can enforce the history cap across existing files (either for one dataset or all datasets). This is not required for correctness because each write already caps the list, but it provides an explicit clean-up hook.

## 8.5 How Memory Improves Quality (Concrete Effects)

The long-term memory mechanisms improve repeated runs in two concrete ways:

- Better planning on repeat analyses:
  - The planner sees "historical context" and can avoid repeating previously known failures.
  - HITL plan review feedback from the last run is available as a prompt grounding signal.

- Faster and safer tool execution:
  - A cached dataset profile reduces redundant inspection.
  - Column argument auto-correction can reference a stable list of valid columns.

These benefits are achieved without introducing a complex retrieval subsystem that would be difficult to evaluate and debug.

## 8.6 Limitations and Guardrails

Known limitations:

- Dataset-key collisions: keying by filename stem can collide across folders.
- No semantic retrieval: history is not searched; only the most recent record is summarized into a snippet.
- Local-only persistence: memory is stored on the server filesystem and is not designed for multi-instance deployments.

Guardrails and caps:

- History cap: max 10 records per dataset key.
- Snippet cap: historical snippet is explicitly truncated to avoid prompt bloat.
- Clipping and depth limits: run metadata fields are clipped before writing.
- Separation of concerns: streaming output is not stored in state and is not persisted as memory.

## 8.7 Evidence Pointers

- Run history store + schema + write policy: `agent_system/src/agents/analysis/pipeline/memory.py`
- Memory load at ingress + profile load: `agent_system/src/agents/analysis/pipeline/runner.py` (`ingest_request`, `_load_persisted_profile`)
- Profile write: `agent_system/src/agents/analysis/pipeline/runner.py` (`_save_persisted_profile`, planner profile persistence)
- Run metadata append after synthesis: `agent_system/src/agents/analysis/pipeline/runner.py` (`synthesis` / `persist_cleanup`)
- Planner prompt inclusion of `historical_snippet`: `agent_system/src/agents/analysis/pipeline/prompts.py` (`build_planner_prompt`)
- Regression test proving HITL plan review persistence into run history: `test_hitl_persistence.py`
