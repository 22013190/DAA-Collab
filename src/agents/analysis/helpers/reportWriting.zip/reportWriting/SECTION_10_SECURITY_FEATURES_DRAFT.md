# 10) Security Features (Guardrails and Policy Enforcement)

This section documents the Analysis Agent’s security-relevant controls and how they are enforced. The core design decision is that **security is enforced at the tool boundary**, not “by prompt.” In practice, the highest-risk actions in an analysis agent are tool calls that can read/write files or generate large outputs.

The guardrails are implemented as lightweight, dependency-free Python logic that is Windows-safe and designed to be testable.

## 10.1 Threat Model and Assumptions

### 10.1.1 Primary risks for this project

The Analysis Agent is a tool-using agent that:

- reads user-supplied datasets (often via `file_path`-style tool args)
- writes outputs (plots, CSVs, reports) to disk
- may receive untrusted instructions embedded in CSV cells or user prompts

The primary risks are therefore:

- **Path traversal / arbitrary file read**: an attacker tries to make a tool read `../...` or an absolute path outside the project allowlist.
- **Output directory escape**: an attacker tries to write outputs to arbitrary locations (e.g., outside the reports directory).
- **Prompt injection steering**: an attacker tries to override the agent’s behavior (“ignore previous instructions”, “reveal secrets”, “read system files”) to exfiltrate data.
- **Resource abuse**: an attacker tries to inflate tool args (huge lists, very large strings, very large `top_n`) to increase cost or crash the pipeline.

### 10.1.2 Non-goals (explicitly out of scope)

- This implementation does **not** claim robust semantic prompt-injection defense.
- This implementation does **not** include sandboxing, OS-level containment, or multi-tenant isolation.
- The system is intended for local evaluation / controlled environments; its controls focus on preventing the most likely tool-boundary escapes.

## 10.2 Security Architecture: Central Policy at the Tool Boundary

### 10.2.1 Where the guardrails live

- Guardrail implementation: `agent_system/src/agents/analysis/pipeline/security_guards.py`
  - `validate_and_resolve_path(...)` (path policy)
  - `ToolCallPolicy.sanitize_args(...)` (tool-call firewall + output-dir forcing + caps)
  - `score_prompt_injection(...)` (heuristic detection)

### 10.2.2 Where the guardrails are applied

The enforcement point is centralized inside the pipeline runner:

- `agent_system/src/agents/analysis/pipeline/runner.py`
  - `execute_step(...)`: builds a policy per-run and calls `policy.sanitize_args(...)` before invoking any MCP tool.
  - If guardrails reject a tool call, the runner records a warning (`"Security policy blocked tool call ..."`) and routes back to the planner to replan around the blocked action.

This design has two benefits:

- **Consistency**: all tools receive the same protections (rather than re-implementing guardrails inside each MCP server).
- **Auditability**: blocks become explicit transcript events and warnings, which then persist into run metadata.

## 10.3 Implemented Controls

### 10.3.1 Path policy (read/write file paths)

The path policy is implemented by `validate_and_resolve_path(...)`:

Rules:

- Reject any path containing parent traversal (`..`).
- Treat relative paths as relative to `repo_root`.
- Allow absolute paths only if they remain under an allowlisted root set.

In the runner, the allowlist includes (best-effort):

- repo root
- `repo_root/agent_system`
- the analysis agent directory
- the configured reports path
- the configured temp datasets path

This is designed to prevent:

- reading `C:\Windows\System32\...`
- reading secrets outside the repo
- writing to unexpected filesystem locations

### 10.3.2 Forced output directory

Any tool arg that looks like an output directory (e.g., `output_dir`, `save_dir`, `out_dir`) is forcibly set to a safe directory:

- forced output dir: `AgentConfig().reports_path`

This ensures that even if an instruction tries to write elsewhere, the tool invocation is constrained to the report output area.

### 10.3.3 Tool argument firewall (drop unknown keys + cap sizes)

Before tool invocation, `ToolCallPolicy.sanitize_args(...)` performs:

- **Unknown-key dropping** (best-effort): if the tool object exposes an `args_schema`, keys not in the schema are dropped with a warning.
- **List caps**: list arguments are capped (default `max_list_items=50`).
- **String caps**: long strings are trimmed (default `max_str_len=4000`).
- **Numeric caps**: common numeric parameters are bounded (e.g., `top_n` capped to `max_top_n=2000`, with a safe fallback if invalid).

This reduces both accidental misuse (LLM hallucinated arg keys) and intentional resource abuse.

### 10.3.4 Unknown tool defense (implicit allowlist)

The pipeline executes only tools present in its internal tool map (`self._tool_map`). If a plan step references an unknown tool name, it is skipped and recorded as a transcript event, rather than being executed.

### 10.3.5 Prompt-injection risk detection (heuristics)

At ingress (`ingest_request`), the runner computes a heuristic injection score for the user instruction:

- `score_prompt_injection(text) -> (score, flags)`
- score threshold: **>= 6** is treated as high risk

If high risk is detected, the runner records a warning string:

- `"Prompt-injection risk detected (score=..., flags=...)"`

Important: in the current implementation, this is a **detection + telemetry mechanism**. It does not by itself block execution; blocking is done by the tool-call policy when a tool call attempts a prohibited action.

## 10.4 Evidence (Tests + Run Artifacts)

### 10.4.1 Unit/regression tests (deterministic)

The guardrails are proven by `test_security_guards.py`, which validates:

- path traversal is blocked (`../secrets.txt`)
- absolute paths outside allowed roots are blocked
- output directory is forced and `top_n` is capped
- injection scoring flags obvious Windows system-file exfiltration attempts

### 10.4.2 Persisted warnings as auditable evidence

The pipeline persists warnings and telemetry into run metadata (`<reports_path>/metadata/<dataset_key>.json`). This means security-relevant signals are auditable after the run.

Example observed pattern in persisted metadata:

- `warnings` includes: `Prompt-injection risk detected (score=..., flags=...)`
- `telemetry` may include counters such as `tool_calls`, `tool_errors`, and `injection_flags`

### 10.4.3 Experiment evidence (aggregated)

The experiment harness aggregates metadata into report-ready metrics:

- `agent_system/src/agents/analysis/helpers/reportWriting/metrics.csv`
- `agent_system/src/agents/analysis/helpers/reportWriting/summary.md`

The current aggregated summary shows that injection detection is being surfaced in the security-labeled runs (sample sizes are explicitly disclosed in Section 9).

## 10.5 Limitations and Future Hardening

- Prompt-injection scoring is heuristic and instruction-only at ingress; it does not inspect dataset cell text unless that text is surfaced in the instruction/context.
- The default charts can show `security_blocked=0` even when guardrails are correct, because block events require an attempted prohibited tool call.
- For stronger evidence, expand the security experiment suite so it reliably executes:
  - explicit `../` traversal probes
  - absolute-path escape probes
  - output-dir escape probes
  - CSV-cell injection probes that attempt to steer file/tool access

Optional future improvements:

- Make injection detection trigger stricter run modes (e.g., require HITL approval before any file-path tool call).
- Add per-tool caps beyond generic list/string/top_n (e.g., max plots per run, max artifact count).
- Add structured experiment tags so the harness can classify security runs without heuristics.
