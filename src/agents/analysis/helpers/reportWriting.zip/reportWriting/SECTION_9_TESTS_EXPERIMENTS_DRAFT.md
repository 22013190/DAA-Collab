# 9) Test Cases & Experiments (with Metrics + Charts)

This section presents (A) the automated tests that validate key behaviors of the Analysis Agent, and (B) experiment-style runs aggregated into report-ready metrics and charts.

The intent is to provide evidence at two levels:

- **Deterministic correctness** (unit/regression tests): safety policies, streaming utilities, HITL persistence, and “viz-only” synthesis outputs.
- **End-to-end behavior under real prompts** (experiments): tool-usage and reliability signals aggregated from run metadata JSON into `metrics.csv` and charts.

## 9.1 Evidence Artifacts and How to Read Them

### 9.1.1 Automated test artifacts

The repo contains a mix of:

- **Pytest unit/regression tests** (fast, deterministic): e.g. guardrails, streaming utilities, metadata persistence.
- **Async “script tests”** (manual/integration): run the pipeline against real datasets and a configured local LLM/MCP environment.

This section cites both types, but distinguishes them so results are not overstated.

### 9.1.2 Experiment aggregation artifacts (report-ready)

These files are generated (or refreshed) by the harness `agent_system/scripts/e2_experiment_harness.py`:

- `agent_system/src/agents/analysis/helpers/reportWriting/metrics.csv`
- `agent_system/src/agents/analysis/helpers/reportWriting/summary.md`
- `agent_system/src/agents/analysis/helpers/reportWriting/e2_guardrails_reliability_summary.png`
- `agent_system/src/agents/analysis/helpers/reportWriting/e2_tool_calls_by_suite.png`

The aggregated files are derived from auditable raw run metadata under the configured reports directory:

- `agent_system/src/agents/analysis/reportDemo/metadata/*.json` (example: `traffic_accidents_cleaned.json`)

## 9.2 Operational Usage (How the Analysis Agent Is Typically Run)

This section is primarily about tests/experiments, but it is helpful to make explicit **how evidence is produced** in day-to-day usage. In this project there are multiple “entrypoints” depending on whether you want a hosted service experience (A2A), a local developer loop (direct pipeline invocation), or a UI.

### 9.2.1 Run as an A2A-compliant service (recommended for streaming + HITL)

The A2A service exposes the analysis pipeline over HTTP with agent discovery and optional streaming:

- Service entrypoint: `python -m agent_system.src.agents.analysis.a2a_compliant_service`
- Environment variables used by the service:
   - `AGENT_DOMAIN` (host/interface)
   - `A2A_ANALYSIS_AGENT_PORT` (port)
- Discovery endpoint: `/.well-known/agent-card.json`

To drive the service and collect realistic “operator experience” traces (including streaming and HITL input-required states), the repo includes a client script:

- A2A client: `agent_system/src/agents/analysis/helpers/a2a_client.py`
   - Sends a dataset path + instruction payload, optionally streams status/artifact events.
   - Supports an auto-reply mode for HITL decisions via `A2A_HITL_REPLY`.

This A2A path is the most representative way to validate user-facing behavior such as:

- progress updates during long-running tool execution
- plan review interrupts and resume decisions
- final report + artifact delivery

### 9.2.2 Run the pipeline directly (developer loop / debugging)

For quick diagnosis and local iteration, the pipeline can be invoked directly without starting the A2A HTTP service.

The typical pattern is:

1) Construct an `AnalysisPipelineState` with `dataset_path` + `instruction`.
2) Seed a `HumanMessage` containing a lightweight “Dataset: … / Instructions: …” header.
3) Call `agent.agent.ainvoke(...)` (or `agent.agent.astream(...)`) with a chosen `recursion_limit`.

A concrete reference implementation of this workflow is:

- `scripts/single_run_trace.py`

This developer-loop path is commonly used for:

- reproducing a single failure deterministically
- testing env toggles (e.g., step caps) without the service layer
- collecting logs with a known run id

### 9.2.3 Run targeted inspection and tool-availability checks (debug scripts)

Some behaviors are easiest to validate via focused scripts that isolate a single stage:

- `test_inspection_only.py` (inspection path; pandas fallback column extraction)
- `debug_agent_planning.py` (enumerates MCP tool availability and prints the dataset-context payload that planning sees)

These scripts help explain “why the pipeline runs the way it does” (e.g., why a plan chose certain tools), and they are useful supporting evidence alongside the aggregate metrics.

### 9.2.4 (Optional) Run via dashboard/UI

For interactive demonstrations, the repo includes a dashboard launcher:

- `agent_system/client/start_dashboard.py`

This provides a user-facing way to exercise the system while keeping the A2A service/pipeline as the underlying execution layer.

### 9.2.5 Where outputs and evidence are written

Across all run modes, the pipeline’s persistent evidence is written under the configured reports directory (`AgentConfig().reports_path`), including:

- run metadata JSON: `<reports_path>/metadata/<dataset_key>.json`
- dataset profiles: `<reports_path>/metadata/<dataset_key>_profile.json`
- generated plots/reports under the reports output subfolders

These metadata files are the auditable source used by the experiment harness to produce `metrics.csv`, `summary.md`, and the report figures.

In practice, each run record typically contains:

- the user-facing inputs (`dataset_path`, `instruction`)
- a compact execution summary (`plan_summary`, `findings_summary`)
- artifact references (`artifacts`)
- operational signals used for evaluation (`telemetry`, `warnings`, `issues`)

This structure is what enables Section 9 to connect “how the pipeline was run” to measurable outcomes (tool call counts, tool errors, injection/blocked flags) without requiring access to model internals.

## 9.3 Test Strategy

The testing strategy is pragmatic:

1) **Lock down security invariants at the boundary** (tool-call policy and path validation), because this is the primary risk surface for an agent that reads/writes files.
2) **Lock down operability behaviors** (streaming throttling/sanitization and HITL persistence), because the system is designed for long-running analyses.
3) **Use integration scripts sparingly** to validate that the LLM-driven components (planning, reflection, synthesis) interact correctly with the real toolchain and real datasets.

## 9.4 Test Matrix (What Is Covered)

The table below lists the highest-signal tests for E2.

| Test file | Type | Primary component(s) | What it validates (claim) |
|---|---|---|---|
| `test_security_guards.py` | Pytest unit/regression | `pipeline/security_guards.py` | Path traversal and outside-root paths are blocked; tool args are sanitized (forced output dir + capped args); injection scoring flags obvious attacks |
| `test_hitl_persistence.py` | Pytest regression | `pipeline/memory.py` | HITL plan review decision (approve/revise/abort + feedback + plan hash + steps) is persisted into run metadata JSON |
| `test_analysis_streaming_utils.py` | Pytest unit | `pipeline/streaming_utils.py` | Streaming output sanitization (ASCII/think-block stripping), status accumulation capping, and throttle logic for snapshot streaming |
| `test_viz_only_minimal_synthesis.py` | Async script/integration | `pipeline/runner.py` (`synthesis`) | Viz-only mode returns a minimal valid report structure (heading + artifact references + summary) without calling an LLM |
| `test_inspection_only.py` | Async script/integration | `pipeline/runner.py` (inspection path) | Dataset inspection via pandas fallback yields correct columns/dtypes and avoids prior “single digit column” failure mode |
| `test_pipeline_fixes.py` | Async script/integration | `pipeline/runner.py` + LLM planner/reflect/interpret/synthesis | End-to-end regression checks for dynamic column extraction, planner column constraints, interpretation error filtering, reflection re-planning, and overall pipeline integration |

Notes on scope:

- The unit/regression tests are designed to be reproducible without requiring MCP servers.
- The script/integration tests typically require a configured local LLM and, for full end-to-end runs, MCP servers.

## 9.5 Experiments: Methodology and Metrics

### 9.5.1 What the harness does

The experiment harness (`agent_system/scripts/e2_experiment_harness.py`) supports two modes:

- **Runner mode** (executes the agent): runs a small suite of capability + security prompts against the compiled pipeline and collects run-level telemetry.
- **Aggregate-only mode**: reads existing metadata JSON files under `AgentConfig().reports_path/metadata` and produces report-ready summaries.

By default, the harness writes outputs into:

- `agent_system/src/agents/analysis/helpers/reportWriting/`

### 9.5.2 How runs are grouped into “capability” vs “security”

The harness computes a `kind` label per run when aggregating metadata. It uses heuristics that classify a run as **security** if any of the following are present:

- A warning indicates a tool call was blocked by policy (`security_blocked = 1`)
- A warning indicates prompt-injection risk detected (`injection_detected = 1`)
- The instruction “looks like” a security probe (e.g., contains “system32”, “ignore previous instructions”, “private key”)
- The dataset path “looks like” a non-dataset file (e.g., `.pem`, `.key`, Windows hosts/system paths)

Otherwise it is labeled **capability**.

This classification makes aggregation robust to mixed metadata sources, but it also introduces a reporting caveat: if some metadata records have missing/blank `instruction` fields, they may be under-counted for the intended suite.

### 9.5.3 Metric definitions (as used in `metrics.csv` / charts)

The harness derives the following from each metadata record:

- `tool_calls`: tool calls recorded for the run (from telemetry when present; otherwise estimated from the plan)
- `tool_errors`: tool execution errors recorded (from telemetry when present; otherwise estimated from textual error patterns)
- `warnings_count` / `errors_count`: counts of pipeline warnings/errors persisted into metadata
- `security_blocked`: 1 if a warning indicates a tool-call was blocked
- `injection_detected`: 1 if a warning indicates injection risk detected

The charts then compute suite-level rates and distributions, including:

- Block rate: mean of `security_blocked`
- Injection-detected rate: mean of `injection_detected`
- Tool error rate per call: $\frac{\sum tool\_errors}{\sum tool\_calls}$
- Run error rate: fraction of runs with `errors_count > 0`

## 9.6 Experiment Results (Aggregated)

The current aggregated results (from `summary.md`) are:

- Total runs aggregated: **7** (unique prompts: **6**)
- capability: **6** (unique prompts: **5**)
- security: **1** (unique prompts: **1**)

Guardrails & reliability summary (suite-level):

- **capability (n=6)**: blocked 0/6 (0%), injection 0/6 (0%), tool-error-any 4/6 (67%), tool-error-rate-per-call 4/41 (10%), run-error-any 1/6 (17%)
- **security (n=1)**: blocked 0/1 (0%), injection 1/1 (100%), tool-error-any 0/1 (0%), tool-error-rate-per-call 0/5 (0%), run-error-any 0/1 (0%)

Tool usage (`tool_calls`) summary:

- capability: mean=6.83, median=5, min=1, max=15
- security: mean=5.00, median=5, min=5, max=5

## 9.7 Figures (Charts)

The following figures are generated directly from `metrics.csv`:

1) `e2_guardrails_reliability_summary.png`
   - Suite-level bars for: blocked rate, injection-detected rate, tool error rate (per call), and run-error rate.
   - Each bar is annotated as “p% (c/N)” to keep the chart interpretable even for small samples.

2) `e2_tool_calls_by_suite.png`
   - Suite-level distribution of tool calls per run.
   - Uses a strip/jitter plot and mean marker for small sample sizes; falls back to boxplots only if sample sizes are large enough.

## 9.8 Reproducibility (How to Regenerate Section 9 Evidence)

From the repo root:

- Aggregate-only regeneration (no LLM/MCP required):
  - `python agent_system/scripts/e2_experiment_harness.py --aggregate-only`

This writes/refreshes `metrics.csv`, `summary.md`, and the PNG charts in:

- `agent_system/src/agents/analysis/helpers/reportWriting/`

## 9.9 Known Limitations and Reporting Caveats

These caveats should be stated explicitly in the final report:

- **Security sample size is currently small** (`n=1` in the aggregated summary). This is due to harness classification heuristics and some metadata records having missing/blank instruction fields.
- **Tool call/error counts may be estimated** when telemetry is missing. The harness records `tool_calls_source` and `tool_errors_source` to disclose when this occurs.
- **All-zero `security_blocked` does not prove guardrails are broken**. It often indicates the evaluated runs did not attempt a blocked tool call.

## 9.10 Evidence Pointers (Code)

- Experiment harness + chart definitions: `agent_system/scripts/e2_experiment_harness.py`
- Raw run metadata (auditable source): `agent_system/src/agents/analysis/reportDemo/metadata/`
- A2A service entrypoint: `agent_system/src/agents/analysis/a2a_compliant_service.py`
- A2A client driver: `agent_system/src/agents/analysis/helpers/a2a_client.py`
- Direct pipeline run example: `scripts/single_run_trace.py`
- Dashboard launcher: `agent_system/client/start_dashboard.py`
- Guardrails implementation: `agent_system/src/agents/analysis/pipeline/security_guards.py`
- Guardrails enforcement point: `agent_system/src/agents/analysis/pipeline/runner.py` (policy application before tool invocation)
- Streaming utilities: `agent_system/src/agents/analysis/pipeline/streaming_utils.py`
- HITL persistence into metadata: `agent_system/src/agents/analysis/pipeline/memory.py`
