# 3) Project Background & Objectives

## 3.1 Project overview and inspiration

This project began from an industry-initiated vision: a multi-agent, GenAI-assisted pipeline that can transform natural-language questions over large operational datasets into decision-ready outputs (reports and dashboards). The initial motivation was to reduce the time and manual effort required to go from “question” to “analysis,” especially for recurring business questions over evolving datasets.

In the original industry framing, the target context includes transportation and smart-city analytics (e.g., traffic and operational datasets) in an environment where stakeholders need both quick answers and reproducible evidence.

As the project evolved through E1 into E2, the system converged toward a stronger architectural separation of concerns, with the **Analysis Agent** becoming the core enabling component. Rather than treating “query-to-dashboard” as a single monolithic capability, the E2 implementation emphasizes a robust, auditable analysis workflow: structured planning, controlled tool execution, persistence of artifacts and run metadata, and interactive governance via human-in-the-loop (HITL) review. This shift reflects a practical lesson: dashboards are only as reliable as the reproducible analysis pipeline and evidence trail that produces them.

Reference framing documents:
- Form B (initial project intent and industry context): `Form B.pdf`.
- Form E1 + Form E1 (Y4T1) (project evolution snapshots): `Form E1 - Progress Report CP.pdf` and `Form E1 - Progress Report CP - Y4T1.pdf`.

## 3.2 Industry relevancy

The project is relevant to real-world analytics teams because it targets common operational constraints:

- **Time-to-insight**: stakeholders often need quick answers (e.g., incident patterns, peaks, anomalies) but analysts must still do careful inspection, cleaning, and visualization.
- **Repeatability and auditability**: in industry settings, analysis needs an evidence trail (what dataset, what steps, what outputs) so results can be reviewed, reproduced, and trusted.
- **Governance for tool-using AI**: when an LLM can call tools that read data and write artifacts, organizations need approvals, guardrails, and logs—especially for sensitive file-system operations.

In the transportation/smart-city domain (as described in the original industry framing), datasets such as traffic incidents and operational logs are high-volume, time-dependent, and frequently revisited. A tool-using Analysis Agent can standardize “first-pass EDA,” accelerate common slicing/visualization, and produce consistent reports while still allowing human oversight.

## 3.3 Project scope and complexity

### In scope
- **Analysis Agent** end-to-end behavior:
  - A2A service interface for tasks and streaming updates.
  - LangGraph pipeline for: ingest → plan → execute tools → interpret → reflect → synthesize → persist.
  - MCP tool servers that perform dataset inspection, statistics, plots, and export.
  - Artifact persistence (plots/reports) and per-run metadata persistence.
  - Security boundary enforcement at tool invocation.

The report scope focuses on the Analysis Agent’s implementation and evaluation evidence, including aggregated run metrics and charts derived from persisted metadata.

### Out of scope (explicit)
- Non-analysis agents and unrelated MAS functionality, except where needed to explain integration boundaries.
- Production deployment hardening beyond the scope of the capstone deliverables.

### Complexity drivers
- **Heterogeneous CSVs** with inconsistent schemas and noisy text fields.
- **Long-running multi-step workflows** where partial progress must be visible and recoverable.
- **Tool boundary risks**: tools accept file paths and output locations, which must be controlled.
- **Reflection/retries**: the system may replan and rerun steps, which complicates evaluation and requires clear telemetry.

## 3.4 Project objectives

The E2 Analysis Agent is designed to meet the following objectives (these are intentionally measurable and mapped to later report sections):

1) **Correctness**: produce structured, tool-backed analyses (not purely narrative) by planning and executing a sequence of verifiable analysis steps.
2) **Operability**: provide streaming progress updates so users can observe long-running analyses and intermediate outputs.
3) **Governance**: support HITL plan review so high-impact analyses can be approved/revised/aborted with decisions persisted.
4) **Continuity**: persist run metadata and artifacts per dataset and reuse that history to improve future runs.
5) **Safety at the tool boundary**: enforce guardrails on tool calls (paths, output dirs, argument caps) and log security-relevant events.

## 3.5 Project outputs and deliverables

The implemented deliverables include:

- **A2A-compliant Analysis Service** that runs the analysis pipeline and streams progress events.
- **LangGraph-based Analysis Pipeline** implementing a structured flow from ingest to synthesis and persistence.
- **MCP Analysis Tool Server(s)** that provide the concrete data operations: inspection/EDA, statistical summaries, plot generation, and export.
- **Persisted artifacts** (reports/plots) written under configured output directories.
- **Persisted run metadata** (per-dataset JSON) including summaries, warnings, and telemetry where available.
- **Automated tests** covering key guardrail behaviors and HITL persistence.
- **Evaluation evidence artifacts** (aggregated CSV + charts) used in Sections 9–10.

For evaluation, the report uses aggregated artifacts (e.g., `metrics.csv` and summary charts) generated from the per-dataset metadata JSON.

## 3.6 Evolution (Form B → E1 → E2)

The project evolved from a broad “multi-agent query-to-dashboard” pipeline into a more rigorous and defensible Analysis Agent design:

- **From aspiration to auditable workflow**: E2 emphasizes reproducible tool-backed steps and persisted evidence rather than only final narrative output.
- **From opaque execution to operable execution**: A2A streaming allows progress visibility across long workflows.
- **From agent autonomy to governed autonomy**: HITL plan review provides a control point aligned with enterprise expectations.
- **From general tools to controlled tools**: guardrails at the tool boundary reflect the security realities of file-system-facing capabilities.

---

# 3B) Literature Review (Key Concepts and Prior Art)

## 3B.1 Goal

This section positions the Analysis Agent’s design choices in established research and industry practice, and motivates why a graph-based orchestration + tool boundary controls + HITL governance is appropriate for a tool-using analysis system.

## 3B.2 Suggested structure (recommended subsections)

### Agentic workflows and tool use
- Planning + acting loops for LLMs (tool selection, structured steps).
- Why tool augmentation is necessary for real analysis (determinism, compute, access to data).

### Reflection and self-correction
- Patterns where an agent critiques intermediate outputs and replans.
- Risks and evaluation implications (retries inflate run counts; need to distinguish runs vs prompts).

### Orchestration as state machines/graphs
- Why a graph/state-machine approach is appropriate for multi-step workflows.
- Benefits: explicit nodes, recoverable transitions, structured state, and testable boundaries.

### Human-in-the-loop governance
- HITL as a control for safety, compliance, and quality.
- Approval gates for high-impact plans and the importance of persisted decisions.

### LLM application security at the tool boundary
- Prompt injection threats when LLMs can call tools.
- File-path and output-dir constraints as a primary defense for file-system-facing tools.
- Allowlisting, argument validation, and output caps as guardrails.

### Evaluation and telemetry
- Why telemetry-based evaluation is preferable to subjective claims.
- Distinguish run-level error rates from per-tool-call error rates.

## 3B.3 Recommended sources to cite (starter set)

Choose a mix of academic + practitioner sources:

- Tool-using agent patterns (e.g., ReAct; tool-augmented reasoning; agent reflection).
- LangGraph / graph-based agent orchestration concepts (official docs and/or technical references).
- Human-in-the-loop in AI systems (governance, auditability, approvals).
- Prompt injection and LLM app security guidance (e.g., OWASP guidance, threat models).
- MCP/tool-server separation patterns (protocol-level boundaries and why they matter).

## 3B.4 Link back to implementation

At the end of the literature review, add a short “design mapping” paragraph:

- The Analysis Agent implements planning + tool use in a structured pipeline.
- Reflection is bounded and evaluated via telemetry.
- HITL is implemented as an explicit interruption/resume mechanism.
- Security controls are enforced at the centralized tool invocation boundary.

