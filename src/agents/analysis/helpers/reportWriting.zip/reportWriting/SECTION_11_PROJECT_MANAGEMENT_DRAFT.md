# 11) Project Management

This section summarizes how the E2 Analysis Agent work was planned, executed, and verified. The emphasis is on **evidence-driven delivery**: each milestone is tied to code, tests, and/or reproducible artifacts.

## 11.1 Planning Approach

### 11.1.1 How work was organized

Work was organized as a sequence of implementation + verification loops:

1) Identify a failure mode (via tests, traces, or observed outputs).
2) Implement a targeted fix in the pipeline/service.
3) Add a regression test or a deterministic script that reproduces the original issue.
4) Produce report-ready evidence (metadata persistence, aggregate metrics, charts).

This approach keeps the agent grounded in actual system behavior rather than “prompt-only” claims.

### 11.1.2 Primary deliverables tracked

At a high level, the E2 Analysis Agent deliverables are:

- A2A-compliant analysis service (discovery + task lifecycle + streaming)
- LangGraph analysis pipeline (plan → execute → interpret → reflect → synthesize)
- HITL plan review interrupt/resume behavior
- Persisted run metadata + dataset profiles (file-backed continuity)
- Guardrails enforced at the tool boundary
- Test cases + experiment harness outputs (metrics + charts)

## 11.2 Timeline and Milestones (E1 → E2)

The following milestones reflect the major increments of E2 work (aligned with the E2 report plan and the repo task list):

- **Pipeline stabilization**
  - Dynamic dataset inspection and planner grounding (no hardcoded columns)
  - Reflection-driven replanning on errors
  - Synthesis quality gating (minimum insight threshold)

- **Operability improvements**
  - Streaming utilities (sanitization + throttling + accumulated snapshots)
  - HITL plan review (pause/resume; decision persistence)

- **Continuity and evidence**
  - File-backed run metadata history and dataset profiles
  - Experiment harness outputs (`metrics.csv`, charts, `summary.md`)

- **Security features**
  - Tool-call firewall + path policy + forced output directories
  - Prompt-injection risk scoring (detection + warnings persisted into metadata)

## 11.3 Planned vs Achieved (Traceability)

The table below maps planned items to delivered outcomes and evidence. Planned items are derived from:

- `agent_system/TODO.md`
- `agent_system/src/agents/analysis/pipeline/E2_FINAL_REPORT_PLAN.md`

| Planned item | Delivered outcome | Evidence (code/tests/artifacts) |
|---|---|---|
| Streaming | A2A streaming support with snapshot-based status updates and throttling utilities | `agent_system/src/agents/analysis/a2a_compliant_service.py`; `agent_system/src/agents/analysis/pipeline/streaming_utils.py`; `test_analysis_streaming_utils.py` |
| HITL gating | Implemented HITL plan review interrupt/resume; decision persisted into run history | `agent_system/src/agents/analysis/pipeline/runner.py` (interrupt/resume wiring); `agent_system/src/agents/analysis/pipeline/memory.py`; `test_hitl_persistence.py` |
| Memory (short-term + continuity) | File-backed run history + dataset profile cache (per dataset key) | `agent_system/src/agents/analysis/pipeline/memory.py`; `agent_system/src/agents/analysis/pipeline/runner.py` (ingress load + profile read/write); report Section 8 draft |
| Guardrails: tool boundary enforcement | Central tool-call policy: path allowlist, forced output_dir, arg caps, schema-based unknown-key dropping | `agent_system/src/agents/analysis/pipeline/security_guards.py`; enforcement in `runner.py::execute_step`; `test_security_guards.py` |
| Experiments and charts | Aggregation harness produces report-ready `metrics.csv`, `summary.md`, and two PNG charts | `agent_system/scripts/e2_experiment_harness.py`; artifacts under `agent_system/src/agents/analysis/helpers/reportWriting/` |
| Remove hardcoding / improve robustness | Dynamic dataset inspection + explicit column constraints + error filtering + replanning + synthesis quality threshold | `agent_system/src/agents/analysis/pipeline/runner.py`; regression scripts `test_inspection_only.py`, `test_pipeline_fixes.py`; summaries `PIPELINE_FIXES_SUMMARY.md`, `FIXES_VERIFICATION_SUMMARY.md` |

## 11.4 Gantt-lite Delivery Table (Week / Deliverable / Status)

This is a concise “what shipped when” view aligned with the section-by-section writing plan.

| Week | Deliverable | Status |
|---|---|---|
| Week 1 | Lock outline, align evidence artifacts, confirm section structure | Completed (plan + handoff docs exist in pipeline folder) |
| Week 2 | Architecture + detailed design + streaming/HITL narrative | Completed (Sections 6–8 drafts + A2A bootstrap documentation) |
| Week 3 | Tests & experiments evidence (metrics + charts) | Completed (Section 9 draft + `metrics.csv` + PNG charts) |
| Week 4 | Security section + polish + final formatting | In progress / ongoing (Section 10 drafted; additional security probes optional) |

## 11.5 Risk Management and Constraints

Key risks encountered and how they were handled:

- **LLM/MCP environment variability** (availability, connectivity, tool adapter differences)
  - Mitigation: keep a core set of deterministic unit/regression tests; provide aggregate-only mode for experiments.

- **Windows-specific runtime issues** (event loop behavior, console encoding)
  - Mitigation: explicit handling in the pipeline/service and ASCII sanitization for streaming/logging.

- **Evidence quality risks** (missing telemetry in metadata)
  - Mitigation: experiment harness discloses estimated tool-call/error counts when telemetry is missing (`*_source` fields).

## 11.6 Remaining Work (Last Month Plan)

Remaining work is explicitly tracked so the final report can be honest about limitations:

- Expand the security experiment suite to increase security sample size beyond `n=1` and to reliably trigger block events.
- Improve harness run classification (reduce reliance on instruction heuristics by adding explicit tags/IDs).
- Optional: improve observability (structured logs, external tracing such as LangFuse) and packaging (Docker/Compose).

## 11.7 Evidence Pointers

- Task list: `agent_system/TODO.md`
- Pipeline fixes summary: `PIPELINE_FIXES_SUMMARY.md`
- Fix verification notes: `FIXES_VERIFICATION_SUMMARY.md`
- Report plan + acceptance checklists: `agent_system/src/agents/analysis/pipeline/E2_FINAL_REPORT_PLAN.md`
- Evidence handoff pointers: `agent_system/src/agents/analysis/pipeline/E2_REPORT_HANDOFF.md`
