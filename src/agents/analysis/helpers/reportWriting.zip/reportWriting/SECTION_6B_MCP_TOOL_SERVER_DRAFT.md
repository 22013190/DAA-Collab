# 6B) Detailed Design: MCP Tool Server (FastMCP)

This section explains the “tool execution” boundary in the system. The analysis pipeline (Section 6) can decide *what* needs to be done, but it cannot directly read files, compute statistics, or generate plots inside the LLM. Instead, it issues structured tool calls to an MCP tool server. This separation is deliberate: the MCP server provides deterministic, testable implementations of data operations, while also acting as a security boundary around the file system and heavy compute.

In this implementation, MCP tools are hosted using FastMCP. The primary server is `agent_system/src/mcp_servers/analysis/fastmcp_server.py` (analysis + visualization tools). A complementary server `agent_system/src/mcp_servers/analysis/data_processing_server.py` provides additional data cleaning/transformation/export and an LLM-assisted message parsing helper.

## 6B.1 Role in the Architecture

The MCP tool server is the “actuator” layer for the agent:

- It takes a **tool name** plus typed **arguments** (e.g., `file_path`, `columns`, `plot_type`).
- It executes those operations using standard Python data-science libraries (pandas, numpy, scipy, sklearn, matplotlib/seaborn).
- It returns **grounded outputs**: either a Markdown/text report, a small JSON payload embedded in the output (used for downstream inference), and/or artifacts saved to disk (typically `.png` plots or cleaned `.csv` exports).

This design makes tool execution reproducible and inspectable: the pipeline’s `tool_transcript` records the tool name, args, status, and returned output/artifact paths, which later becomes the evidence substrate for interpretation and synthesis.

## 6B.2 Tool Categories (What Exists)

The analysis server provides tools that fall into a small number of categories.

**Dataset inspection and schema grounding.** The first-step tool is `load_and_analyze_csv(file_path, auto_expand_json=...)`, which loads the dataset, reports rows/columns/types/missingness, and appends a machine-readable JSON footer. That footer contains detected column types (numeric/categorical/datetime) and is intentionally used to reduce “invented column” errors.

**Exploratory data analysis and statistical tests.** Tools such as `perform_advanced_eda_on_csv(...)` and other analysis helpers compute descriptive statistics, correlations, and (where relevant) hypothesis tests. These tools produce a Markdown-formatted summary that the pipeline can quote from.

**Visualization and artifact generation.** The plotting tools (e.g., `generate_plot(...)`, `generate_correlation_heatmap(...)`, and temporal plot modes) produce a PNG image saved to disk. They return a Markdown image reference plus a “Saved:” path so the pipeline can register artifacts deterministically.

**Specialized temporal/text analysis.** Domain-specific helpers such as `analyze_temporal_patterns(...)` and `analyze_text_content(...)` provide higher-level analyses (e.g., time-of-day distributions, temporal aggregation, or basic text statistics), again returning grounded textual summaries.

The complementary data-processing server adds:

- **Cleaning:** `clean_dataset(file_path, remove_duplicates, handle_missing)` writes a cleaned dataset to disk.
- **Transformation:** `transform_data_types(file_path, column_types)` converts columns using a JSON mapping.
- **Export:** `export_processed_data(...)` writes processed data to a requested format.
- **LLM-assisted parsing:** `llm_message_parser(content, format_hint)` attempts to normalize arbitrary messages into structured JSON (used when integrating agent-to-agent workflows).

## 6B.3 File and Artifact Behavior

Tools follow a consistent I/O pattern:

- Read input datasets from `file_path`.
- Produce either (a) a Markdown/text report, (b) derived datasets saved alongside the input (e.g., `_cleaned.csv`), and/or (c) plot image artifacts saved under a specified `output_dir`.

Plotting tools are designed to return artifact references that the pipeline can discover later even if the path is only present in the output text. The pipeline also performs its own artifact discovery pass in visualization-only mode by parsing tool outputs and scanning the plots directory.

## 6B.4 Performance Behaviors (Caching)

The analysis MCP server maintains a dataset cache (`_dataset_cache`) keyed by a file hash. This cache reduces repeated disk I/O when multiple tools need to read the same dataset during one run (e.g., inspection → EDA → plotting). In practice, caching is critical for interactive usage and for keeping tool latency acceptable when the pipeline executes several sequential steps.

## 6B.5 Guardrails and Why the MCP Server is a Security Boundary

The MCP server is the only component that touches the file system and executes code that can be expensive (plotting, ML, large-data aggregation). For that reason, the system treats the tool interface as a boundary:

- The pipeline enforces a centralized tool-call policy (path validation, allowed roots, forced output directory, and argument sanitation) before a tool is executed.
- On violations, the pipeline records a blocked tool event and requests replanning rather than executing unsafe operations.

This is intentionally a “defense in depth” design: even if an instruction is malicious or the LLM proposes unsafe paths, the tool-call firewall prevents filesystem escape and constrains where artifacts can be written.

## 6B.6 Representative Tool Signature (Filesystem + Output Dir)

The plotting tool below illustrates the common pattern: an input `file_path` plus an explicit `output_dir` for artifacts.

```python
@mcp.tool()
def generate_plot(
    file_path: Annotated[str, Field(description="Path to the CSV file to plot")],
    plot_type: Annotated[Literal[...], Field(description="Type of plot to generate")],
    x_column: Annotated[str, Field(description="X-axis column")] = None,
    y_column: Annotated[str, Field(description="Y-axis column")] = None,
    hue_column: Annotated[str, Field(description="Optional color encoding column")] = None,
    title: Annotated[str, Field(description="Title of the plot")] = "Generated Plot",
    output_dir: Annotated[str, Field(description="Directory to save the plot image file")],
) -> str:
    ...
```

From the pipeline’s perspective, this signature is important because it makes the artifact path explicit and therefore enforceable by guardrails (forced output directory) and discoverable for report generation.

## 6B.7 Acceptance Checklist Mapping

Errors and robustness are handled at the boundary between pipeline and tools:

- If a tool cannot find a file/column, it returns a structured error string; the pipeline records that as an error event and can trigger refinement/replanning.
- If a tool attempts to write an artifact, the pipeline can force the output directory and later confirm artifacts were produced (via transcript parsing and plots directory scanning).
- If a tool call is blocked by policy, the pipeline records the policy violation and requests a safe replan.
