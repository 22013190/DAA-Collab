# 6) Detailed Design: Pipeline (LangGraph)

This section explains the analysis agent’s execution pipeline as an explicit state machine. The implementation uses LangGraph’s `StateGraph` to make control-flow, retries, and termination conditions inspectable and testable, rather than relying on an implicit “LLM loop”. The design goal is to (a) execute a bounded, sequential tool plan; (b) convert raw tool outputs into evidence-backed insights; and (c) either conclude with a report or safely replan when coverage is insufficient.

The pipeline is implemented in `agent_system/src/agents/analysis/pipeline/runner.py` and is exposed to clients through the A2A-compliant service layer (see Section 7 for streaming/pause/resume behavior).

## 6.0 External Contract: Inputs, Outputs, and Run Modes

End-to-end, the pipeline has one input schema (`AnalysisPipelineState`) and one output envelope (`PipelineOutputState`). The A2A service layer converts client messages into one of two execution modes:

In a **fresh run**, the service parses a `dataset_path` plus free-text `instruction` from the incoming A2A message and seeds a state object. The seed includes a minimal `messages` history (a single `HumanMessage` containing dataset + instruction) and the scalar fields `dataset_path` and `instruction`. This seed state is then passed into the LangGraph runtime.

In a **resume run** (HITL), the service passes `Command(resume=<payload>)` to LangGraph instead of a full state object. This resume payload contains the plan review decision (e.g., approve/revise/abort) and optional feedback. The ability to resume is tied to the same `context_id` (wired into LangGraph as `configurable.thread_id`) and requires a checkpointer when interrupts are enabled.

On the output side, the pipeline returns a `PipelineOutputState` envelope that is designed for safe transport and evaluation:

- `status`: `ok` or `error`.
- `report_text`: the final Markdown report (or a diagnostic error report when planning cannot proceed).
- `artifacts`: a structured dict of artifacts and metadata, including saved report paths and (optionally) telemetry.
- `steps` and `tool_summaries`: structured execution traces that can be rendered in the UI or used as evidence.
- `warnings` / `errors`: merged, capped lists of non-fatal and fatal issues.

The A2A layer typically exposes `report_text` as the main “analysis_result” and forwards `artifacts` for downstream consumers.

## 6.1 Control-Flow Overview (Graph + Nodes)

The pipeline is built as a directed graph with a small number of nodes that each have a single responsibility:

- `ingest_request`: normalize inputs, load cached dataset profile, load “run history” memory snippet, and initialize derived state.
- `planner`: produce a structured list of tool steps (`plan_steps`) grounded in the current instruction and dataset profile.
- `execute_step`: execute exactly one tool step at a time and append an event to `tool_transcript`.
- `interpret_results`: convert recent successful tool outputs into grounded `insights` plus a `coverage` assessment.
- `reflect`: decide whether to synthesize immediately or to request replanning based on `coverage` and guardrails.
- `synthesis`: generate the final report (strict JSON-first, then deterministic Markdown rendering) and register artifacts.
- `persist_cleanup`: persist the report to disk, and schedule run-metadata persistence to long-term “run history”.

LangGraph routing is intentionally explicit: static edges move `START → ingest_request → planner → execute_step`, and then conditional routers determine whether the system continues executing steps, interprets results, replans, or terminates. This avoids uncontrolled cyclic edge expansion (a previously observed failure mode when multiple outgoing edges enabled accidental post-final recursion).

Two runtime configuration concepts are important for end-to-end behavior:

First, the service supplies a `recursion_limit` to the graph execution to allow bounded internal loops (execute/interpret/reflect/replan) without risking runaway recursion.

Second, when executing via the streaming A2A path, the service always supplies `configurable.thread_id=context_id`. When HITL is enabled, the pipeline compiles the graph with an in-memory checkpointer; the thread id is what allows the interrupt/resume to target the correct execution thread.

## 6.1.1 End-to-End I/O by Node (Inputs → Process → Outputs → Next)

The table below is a compact “contract” for the pipeline. It makes explicit what each node consumes from state, what it produces, and how the run progresses.

| Stage | Primary inputs (read) | Primary process (logic goal) | Primary outputs (write) | Next hop (routing) |
|---|---|---|---|---|
| `ingest_request` | `dataset_path`, `instruction`, `messages` | Trim message window; score prompt-injection risk; load run-history snippet; load persisted dataset profile (if available) | `historical_snippet`, `preprocess_profile` (optional), `warnings` (optional), `telemetry` (optional) | Always `planner` |
| `planner` | `instruction`, `historical_snippet`, `preprocess_profile`, `refinement_request`, tool catalog | Produce validated bounded `plan_steps` (`{tool,args,why}`); set `output_mode` and `visualization_only`; compute `plan_hash`; set `finalize` if no valid steps or plan unchanged+exhausted | `plan_steps`, `plan_hash`, `next_step_index`, `finalize`, `replan_no_change`, `telemetry.planner_calls`; plus HITL fields/messages when enabled | Normally `execute_step`; may `interrupt(...)` when HITL plan review enabled (resume returns here) |
| `execute_step` | `plan_steps`, `next_step_index`, `finalize`, tool map/policy config | Execute exactly one tool call; enforce tool-call firewall + forced output dir; auto-correct column args (best-effort); append structured event to transcript | `tool_transcript` (+ event), `next_step_index` increment; `telemetry.tool_calls/tool_errors`; `warnings` on policy blocks | Continue `execute_step` while steps remain; route to `interpret_results` when finished; route to `planner` on blocked call (replan) |
| `interpret_results` | `tool_transcript` (recent), `plan_steps`, `next_step_index` | Filter out error events; extract evidence snippets; call LLM for strict JSON; verify evidence is literal; compute `coverage` and grounded `insights` | `insights`, `coverage`, `token_metrics.interpret`, `telemetry.interpret_calls` | Always `reflect` |
| `reflect` | `coverage`, `tool_transcript`, `plan_steps`, `next_step_index`, `refinement_round`, `replan_no_change`, `plan_retries`, `finalize` | Deterministically decide: synthesize vs replan vs keep executing; apply loop caps (refinement rounds, replan-without-change) and recovery rules | `refinement_request` (when missing info), `refinement_round`, `plan_retries`, optionally `finalize` | `synthesis` if answered/finalize/capped; otherwise `planner` (replan) or `execute_step` (remaining steps) |
| `synthesis` | `insights`, `coverage`, `tool_transcript`, `artifact_log`, `dataset_path`, `output_mode` | Generate final report (strict JSON-first + evidence verification); minimal viz-only report when configured; cache output for single-run guard | Returns `PipelineOutputState`: `status`, `report_text`, `summary`, `artifacts`, `steps`, `tool_summaries`, `token_metrics`, `warnings`, `errors` | `persist_cleanup` |
| `persist_cleanup` | `PipelineOutputState` (envelope), internal run id | Save report markdown (idempotent); schedule run-metadata persistence (run history); attach `report_path` artifact | Mutates `output.artifacts` (`report_path`, `__report_saved`) and schedules memory append | `END` |

Note: graph-level routers mirror these rules and ensure progress is bounded (execute while steps remain; interpret once steps are complete; reflect decides replan vs synth). This separation keeps routing deterministic and keeps LLM calls confined to planning/interpretation/synthesis.

**TODO (figure):** Insert the draw.io sequence diagram “AADi3” here to visually show the steady-state loop: `planner → execute_step* → interpret_results → reflect → (planner | synthesis)`.

## 6.2 State Model (Key Fields)

The pipeline uses a single shared state object (`AnalysisPipelineState`) that is reduced/merged across node updates. Only the most important fields are listed here.

- `plan_steps`: ordered list of steps, where each step is a dict containing `{tool, args, why}`.
- `plan_hash`: stable hash of the current plan (used to detect “replan produced no change”).
- `next_step_index`: index of the next plan step to execute.
- `tool_transcript`: append-only list of tool execution events (tool name, args, status, outputs, artifacts, timestamps).
- `insights`: list of evidence-backed insight objects derived from tool outputs (deduped and capped).
- `coverage`: structured decision signal from interpretation: `{answers_query: bool, missing_info: [..]}`.
- `artifact_log`: list of generated output artifacts (plots, exports, report paths).
- `hitl_plan_reviewed`, `hitl_plan_decision`, `hitl_plan_feedback`: plan-review HITL fields (approve/revise/abort) when HITL is enabled.
- `telemetry` and `token_metrics`: lightweight counters used for evaluation and debugging (e.g., number of tool calls, interpret calls).
- `finalize`: boolean that forces early termination toward synthesis when continuing would be unproductive.

Although the report focuses on the above “headline fields”, the complete state schema also includes operational controls that matter to end-to-end correctness:

- `messages`: the LangChain message channel (trimmed to a small window at ingress).
- `warnings` / `errors`: state-level warnings and errors accumulated during execution.
- `historical_snippet`: the “run history” memory snippet loaded at ingress (if available).
- `preprocess_profile`: cached dataset profile (columns, dtypes, samples) used to ground planning and argument correction.
- `refinement_request` and `refinement_round`: the concrete “missing_info” items and the capped number of refinement loops.

Two practical points matter for correctness:

1) **The state is bounded.** The reducers in `agent_system/src/agents/analysis/pipeline/state.py` cap transcript length and deduplicate repeated events/insights so that long runs do not overflow context windows.

2) **Termination conditions are state-driven.** The pipeline does not rely on “the LLM decides to stop”; instead, it routes based on explicit state flags (`finalize`, step caps, `coverage.answers_query`, plan exhaustion, and retry counters).

## 6.3 Planner (Structured Plan Generation)

The `planner` node constructs a bounded set of tool calls that can be executed deterministically. It validates the produced steps, computes a `plan_hash`, and decides whether the system should reset `next_step_index` or preserve it.

A key anti-loop guard is the “plan unchanged and exhausted” check: if reflection causes a replan but the plan does not change and all steps were already executed, the planner marks `finalize=True` to prevent a non-progressing `reflect → planner` loop.

The planner also increments telemetry (`planner_calls`) so evaluation can reason about run complexity without parsing logs.

If HITL plan review is enabled, the planner can intentionally interrupt after producing a validated plan. That interrupt is surfaced by the A2A service as an `input-required` state (Section 7), and the graph is resumed later with the plan-review decision.

## 6.4 Sequential Execution (execute_step)

The `execute_step` node executes exactly one planned step and records the result in `tool_transcript`. This node is deliberately small-grained because it enables:

- precise step-level guardrails (tool-call firewall, path/output enforcement),
- deterministic “continue executing while steps remain”, and
- fine-grained error handling (block, skip, or replan) without losing the full transcript.

Two termination safety features are applied before executing tools:

- **Global step cap:** a run-level cap finalizes the run if too many steps execute across a single request.
- **Single-run guard:** if synthesis has already completed (and cached output), further node execution routes to `END`.

If a tool call is blocked by security policy, the node logs an error event and asks the planner to replan around the blocked operation.

The tool transcript is intentionally structured. Each tool event is a dict that includes (at minimum) the `tool` name, `args`, a `status` (`ok`, `skip`, or `error`), a human-readable `output`/`result` string, an optional `artifact` path (or other artifact hints), a `timestamp`, and the step rationale (`why`). This transcript is later used as the authoritative evidence substrate for interpretation and synthesis.

## 6.5 Interpretation (interpret_results) and Reflection (reflect)

After all steps are executed (or a finalize condition is raised), `interpret_results` extracts a compact view of *recent successful* tool outputs and prompts the LLM for strict JSON containing insights plus a coverage assessment. Error entries are filtered out before interpretation to avoid contaminating “evidence”.

The `reflect` node is a deterministic policy layer that converts `coverage` into a control decision:

- If the query is answered (or nothing actionable is missing), route to `synthesis`.
- If actionable `missing_info` exists, store it into `refinement_request` and route to `planner`.

The reflect node also contains loop-prevention and recovery logic. For example, if the transcript contains tool errors but no successes, it requests a column-aware replan (using the dataset’s real columns) with a strict cap on the number of refinement rounds. If replanning repeatedly returns the same plan (`replan_no_change`), a retry counter (`plan_retries`) is incremented and capped; once exceeded, the run finalizes to synthesis rather than looping.

At the graph level, these decisions are mirrored by conditional routing functions (e.g., the execute router continues calling `execute_step` while `next_step_index < len(plan_steps)`, routes to `interpret_results` after the last step, and short-circuits to interpretation if the plan is empty). This routing layer is deliberately “dumb” (no LLM calls) and exists to make termination and progress conditions explicit.

## 6.6 HITL Plan Review (Interrupt → Resume)

When plan-review HITL is enabled (via environment flags), the pipeline interrupts *after* producing a validated plan but *before* executing tools. This provides a safe checkpoint where a human can approve, request a revision (with feedback), or abort.

The planner defaults to reviewing only the first plan in a run (to avoid repeated interruptions on replans), but it can be configured to review each replan.

### Snippet: planner HITL decision handling

```python
# Phase 4: HITL plan review (interrupt -> requires_input -> resume)
...
if hitl_enabled:
    ...
    if (not already_reviewed) and (not bool(updates.get("finalize"))):
        payload = {
            "type": "plan_review",
            "plan_steps": list(validated),
            ...
        }
        decision = interrupt(payload)
        ...
        if raw_decision in ("approve", ...):
            updates["hitl_plan_reviewed"] = True
            updates["hitl_plan_decision"] = "approve"
            return Command(update=updates, goto="execute_step")

        if raw_decision in ("revise", ...):
            updates["hitl_plan_reviewed"] = False
            updates["hitl_plan_decision"] = "revise"
            updates["messages"] = [HumanMessage(content=f"Plan feedback: {feedback}")]
            return Command(update=updates, goto="planner")

        if raw_decision in ("abort", ...):
            updates["hitl_plan_reviewed"] = True
            updates["hitl_plan_decision"] = "abort"
            updates["finalize"] = True
            return Command(update=updates, goto="execute_step")
```

At the service layer, this interrupt is surfaced as an A2A `requires_input` transition and the client can resume by sending a structured `hitl_resume` payload. This behavior is explained and evidenced in Section 7.

## 6.7 Synthesis and Persistence (synthesis → persist_cleanup)

The `synthesis` node generates the final report using a strict JSON-first strategy and evidence verification: insights are verified against the tool transcript and/or artifacts, and unsupported insights are dropped. This is a deliberate design choice to minimize hallucinated claims.

The synthesis output is written into the `PipelineOutputState` envelope, rather than back into `AnalysisPipelineState`. For this reason, the pipeline includes a “single-run guard” and caching behavior: once synthesis completes, later nodes can return cached output (or route to `END`) rather than re-running expensive work.

After synthesis, `persist_cleanup` (a) saves the report markdown to the configured reports directory and (b) schedules a run-metadata append into the long-term “run history” store. It also applies idempotency rules to prevent duplicate writes per run unless explicitly configured.

Separately from report persistence, the A2A entrypoint also applies an idempotency cache keyed by `(dataset_path, instruction)` for a short TTL. This prevents accidental repeated submissions from re-running the entire pipeline when the service receives identical requests in quick succession.

## 6.8 Correctness and Loop-Prevention (Reducers + Caps)

LangGraph reducers in `agent_system/src/agents/analysis/pipeline/state.py` enforce bounded growth and deduplication:

- `tool_transcript` is merged with a content-hash signature and capped to a maximum entry count.
- `insights` are deduplicated by `(statement, evidence)` and capped by `ANALYSIS_MAX_INSIGHTS_STATE`.

Together with runtime caps (global step cap, refinement cap, max replan-without-change attempts, single-run guard), these mechanisms ensure the pipeline terminates predictably even under LLM failures, tool errors, or adversarial inputs.
