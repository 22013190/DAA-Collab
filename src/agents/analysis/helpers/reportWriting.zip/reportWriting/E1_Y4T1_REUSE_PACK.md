# E1 Y4T1 → E2 Reuse Pack (Analysis Agent)

Purpose: make it easy to reuse the best parts of your E1 Y4T1 report in the E2 final report **without copy/pasting outdated “progress report” language**.

Primary reference:
- `agent_system/src/agents/analysis/helpers/Form E1 - Progress Report CP - Y4T1.pdf`

E2 plan anchor:
- `agent_system/src/agents/analysis/pipeline/E2_FINAL_REPORT_PLAN.md`

---

## Reuse rules (so it reads like E2, not E1)

- Convert tense: **planned/ongoing** → **implemented/evaluated**.
- Replace “accomplishments during the period” with **final design decisions and rationale**.
- If a claim is numeric, tie it to **current E2 evidence** (`metrics.csv`, charts, metadata JSON).
- Keep good explanatory paragraphs; cut report-form boilerplate.

---

## High-value reuse mapping (E1 Y4T1 section → E2 section)

### 1. Introduction (E1) → 3. Project Background & Objectives (E2)

**Reuse (high):** motivation, problem framing, why automation matters.

**Update required:**
- Make the “query-to-dashboard” vision consistent with the E2 reality: the **Analysis Agent** is the core engine that produces reproducible artifacts + evidence.
- Align terminology with E2 pipeline naming and A2A/HITL.

**E2-ready paragraph starter:**
> This project originated from an industry-driven need to reduce the manual effort required to transform natural-language questions over operational datasets into repeatable analytical outputs. In E2, the work is formalized into an Analysis Agent that plans and executes tool-backed analysis steps, streams progress, and persists both artifacts and run metadata for auditability.


### 2. Literature Review (E1) + 7. Background Research and References (E1) → 3B. Literature Review (E2)

**Reuse (high):** topic structure and explanations.

**Update required:**
- Add at least one paragraph that explicitly maps each literature theme to your implementation (LangGraph node graph, MCP tool boundary, HITL, guardrails).
- Ensure references include up-to-date sources (e.g., OWASP LLM guidance; framework docs).

**E2-ready paragraph starter:**
> Prior work on tool-using agents motivates separating “reasoning” from “execution.” In this project, that separation is realized via an MCP tool server (execution) orchestrated by a LangGraph pipeline (reasoning/control), with human-in-the-loop approval used as a governance layer for high-impact plans.


### 3. Planned Tasks and Objectives (E1) → 3. Objectives + 4. Requirements (E2)

**Reuse (medium-high):** objective list and scope.

**Update required:**
- Convert objectives into requirements with verification methods (tests/experiments).
- Replace “replace cloud LLM with local model” content **only if it remains true in E2**.

**E2-ready requirement-table row starter:**
- FR (Operability): Stream progress updates during analysis; implemented in A2A service and pipeline event emission; verified via service trace and demo.


### 4. Accomplishments During the Reporting Period (E1) → 6/6B/7/8 (E2)

This is where you get big page count with real content.

**4.1 Deterministic State-Graph Workflow** → Section 6 (Pipeline)
- Reuse the node sequence explanation.
- Update with E2 node names and how reflection/retries are bounded.

**4.3 Tool orchestration with FastMCP** → Section 6B (MCP Tool Server)
- Reuse the argument for modular tools.
- Update with tool categories + I/O boundary + security risks.

**4.5 A2A-style structured comms** → Section 7 (Streaming & HITL)
- Reuse the “why structured updates” explanation.
- Update with current message/event names and HITL pause/resume.

**4.4 Session memory** → Section 8 (Memory)
- Reuse the rationale for persistence.
- Update with the actual metadata JSON path + what fields are persisted.

**E2-ready paragraph starter (Pipeline design):**
> The Analysis Agent is implemented as an explicit state machine (LangGraph) to make execution order and recovery paths deterministic. Each node has a single responsibility (ingest, plan, execute tools, interpret, reflect, synthesize, persist), enabling targeted testing and clear telemetry attribution.


### 8. Requirements Gathered (E1) → 4. Requirements (E2)

**Reuse (high):** table structure and grouping (FR/NFR).

**Update required:**
- Add “how verified” column and point to specific tests + evidence artifacts.


### 9. Implementation Details (E1) → 5/6/6B/7/8 (E2)

**Reuse (high):** descriptions of architecture choices.

**Update required:**
- Replace any outdated module paths / naming.
- Add figure references you will include in E2 (architecture overview + pipeline flow + HITL sequence).


### 10. Testing Approaches and Cases (E1) → 9. Tests & Experiments (E2)

**Reuse (medium-high):** testing philosophy and categorization.

**Update required:**
- Use the E2 evidence outputs:
  - `agent_system/src/agents/analysis/helpers/reportWriting/metrics.csv`
  - `agent_system/src/agents/analysis/helpers/reportWriting/e2_guardrails_reliability_summary.png`
  - `agent_system/src/agents/analysis/helpers/reportWriting/e2_tool_calls_by_suite.png`
  - `agent_system/src/agents/analysis/reportDemo/metadata/traffic_accidents_cleaned.json`

**E2-ready paragraph starter:**
> In addition to unit tests for guardrails and HITL persistence, we ran an experiment suite and aggregated run metadata into a metrics table and charts. This provides objective evidence of tool usage, tool error rates, and security warnings across capability and security prompts.


### 11. Technical Challenges and Solutions (E1) → 11. Project Management + 6/9/10 (E2)

**Reuse (high):** the “challenge → fix → evidence” framing.

**Update required:**
- Re-anchor each fix to final code locations and tests.

**E2-ready paragraph starter:**
> Early iterations exhibited unstable planning and ambiguous tool selection. The final design mitigates this through a strict plan schema, tool allowlisting, and centralized argument sanitization at the tool boundary, with failures recorded as warnings and summarized in persisted run metadata.


### 12–13. Knowledge (E1) → 11. Project Management (E2)

**Reuse (medium):** keep 1–2 pages, make it concise.


### 15. References (E1) → 13. References (E2)

**Reuse (medium):** as a baseline list.

**Update required:**
- Ensure every key concept in 3B has at least one credible citation.

---

## “Do not reuse as-is” list

- Administrative form sections (A. Preamble, Declarations).
- Anything that reads like “during this reporting period …” without converting to final-state narrative.
- Any metric numbers that don’t match the current E2 evidence artifacts.

---

## Fast path: recommended reuse workflow

1) Copy the strongest paragraphs from E1 Y4T1:
   - Introduction framing
   - Literature themes
   - Challenge/fix narratives
2) Replace all progress-report phrasing.
3) Insert E2 evidence links (tests, charts, metrics).
4) Ensure Section 3 (overview) references Form B and explains the evolution.

