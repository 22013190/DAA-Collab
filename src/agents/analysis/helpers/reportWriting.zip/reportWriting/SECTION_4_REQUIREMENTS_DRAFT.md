# 4) Requirements (Functional + Non-Functional)

## 4.1 Overview

This section translates the project goals into assessable requirements. Each requirement is mapped to:

- **Design choice** (how the requirement is satisfied)
- **Where implemented** (key modules)
- **How verified** (tests, experiments, or evidence artifacts)

This makes the E2 report defensible: claims are grounded in code and measurable evidence.

## 4.2 Functional Requirements (FR)

| ID | Requirement | Priority | Design choice | Where implemented | How verified |
|---|---|---|---|---|---|
| FR1 | Provide streaming progress updates during long-running analyses. | High | A2A task streaming with incremental status/progress events emitted from pipeline nodes and tool execution, with throttling/caps to avoid flooding. | `agent_system/src/agents/analysis/a2a_compliant_service.py`, `agent_system/src/agents/analysis/pipeline/runner.py`, `agent_system/src/agents/analysis/pipeline/streaming_utils.py` | Unit tests for throttling/sanitization: `test_analysis_streaming_utils.py`; streaming/HITL contract: `agent_system/src/agents/analysis/pipeline/STREAMING_AND_HITL_PLAN.md`. |
| FR2 | Execute analysis as a structured, multi-step workflow (not a single-shot response). | High | LangGraph state-machine with explicit nodes for ingest, planning, tool execution, interpretation, reflection, synthesis, and persistence. | `agent_system/src/agents/analysis/pipeline/runner.py` | Node-level regression coverage: `test_pipeline_fixes.py` (`test_dataset_inspection`, `test_planner_column_constraint`, `test_interpretation_error_filtering`, `test_reflection_replanning`); end-to-end evidence from auditable run records: `agent_system/src/agents/analysis/reportDemo/metadata/traffic_accidents_cleaned.json` and aggregated tool-call metrics in `agent_system/src/agents/analysis/helpers/reportWriting/metrics.csv`. |
| FR3 | Generate and persist stable artifacts (plots/reports) that can be referenced in a report. | High | Tools write outputs under configured output directories; pipeline collects and references artifacts and persists a per-dataset run record. | MCP tool server modules (e.g., `agent_system/src/mcp_servers/analysis/fastmcp_server.py`), pipeline persistence | Auditable run outputs exist under `agent_system/src/agents/analysis/reportDemo/metadata/` (e.g., `analysis_report_traffic_accidents_*.md` and per-dataset history like `traffic_accidents_cleaned.json`); evaluation figures exported under `agent_system/src/agents/analysis/helpers/reportWriting/`. |
| FR4 | Support HITL plan review (APPROVE/REVISE/ABORT) and resume execution in the same context. | High | Pipeline interrupts at plan review, A2A service emits `input-required`, client resumes with decision payload. | `agent_system/src/agents/analysis/pipeline/runner.py`, `agent_system/src/agents/analysis/a2a_compliant_service.py`, client helper(s) | Unit/regression: `test_hitl_persistence.py`; streaming/HITL contract: `agent_system/src/agents/analysis/pipeline/STREAMING_AND_HITL_PLAN.md`. |
| FR5 | Persist run metadata per dataset and ingest recent history into future runs. | High | Per-dataset JSON run history (summaries, warnings, telemetry) loaded at ingest to provide historical snippet/context. | `agent_system/src/agents/analysis/pipeline/memory.py`, `agent_system/src/agents/analysis/pipeline/runner.py` | Auditable evidence: `agent_system/src/agents/analysis/reportDemo/metadata/traffic_accidents_cleaned.json`; aggregation proof: `agent_system/src/agents/analysis/helpers/reportWriting/metrics.csv` derived from metadata. |
| FR6 | Constrain tool usage to known/allowed tools (avoid arbitrary tool calls). | High | Tool map allowlist; unknown tool steps are skipped with explicit transcript entry. | `agent_system/src/agents/analysis/pipeline/runner.py` | Enforcement behavior implemented in `execute_step` (records `status="skip"` with message `Skipped: unknown tool...`); pipeline robustness validated by node-level regressions in `test_pipeline_fixes.py` and auditable `tool_transcript` persisted in per-dataset metadata JSON (e.g., `agent_system/src/agents/analysis/reportDemo/metadata/traffic_accidents_cleaned.json`). |
| FR7 | Support data inspection/EDA, statistics, and visualization via MCP tools. | Medium | Separate MCP tool server(s) provide concrete data operations; agent selects tools via plan steps. | `agent_system/src/mcp_servers/analysis/fastmcp_server.py`, `agent_system/src/mcp_servers/analysis/data_processing_server.py` | Evidence from real runs: plot artifacts saved under `agent_system/src/agents/analysis/reportDemo/metadata/` (e.g., `Temporal_Heatmap_*_temporal_heatmap_*.png`) and tool-call counts summarized in `agent_system/src/agents/analysis/helpers/reportWriting/metrics.csv`; synthesis-side artifact reporting validated by `test_viz_only_minimal_synthesis.py`. |
| FR8 | Provide evidence artifacts for evaluation (metrics + charts) from real runs. | High | Run metadata is aggregated by an experiment harness into a CSV and charts suitable for the report. | `agent_system/scripts/e2_experiment_harness.py` | Generated: `agent_system/src/agents/analysis/helpers/reportWriting/metrics.csv`, `summary.md`, `e2_guardrails_reliability_summary.png`, `e2_tool_calls_by_suite.png`. |

## 4.3 Non-Functional Requirements (NFR)

| ID | Requirement | Priority | Design choice | Where implemented | How verified |
|---|---|---|---|---|---|
| NFR1 | Windows-safe logging and file I/O behavior. | Medium | Prefer ASCII-safe streaming payloads; deterministic path handling via `pathlib`; avoid problematic encodings in status updates. | `agent_system/src/agents/analysis/pipeline/streaming_utils.py` (e.g., `ascii_sanitize`), pipeline/service logging | Unit tests: `test_analysis_streaming_utils.py` (e.g., `ascii_sanitize`, caps/throttling). |
| NFR2 | Avoid state bloat during streaming; keep streaming data out of long-lived state where possible. | Medium | Stream events are emitted, while persistent state stores only necessary summaries/transcripts/telemetry; streaming text is capped and throttled. | `agent_system/src/agents/analysis/a2a_compliant_service.py`, `agent_system/src/agents/analysis/pipeline/streaming_utils.py` | Unit tests enforce bounded streaming helpers: `test_analysis_streaming_utils.py` (caps via `StatusAccumulator(max_chars=...)` and rate limiting via `StreamThrottle`). |
| NFR3 | Deterministic persistence locations for metadata and artifacts. | High | Centralized config controls reports/plots paths; per-dataset metadata JSON under a consistent directory structure (including legacy compatibility). | Config modules + `agent_system/src/agents/analysis/pipeline/memory.py` persistence | Regression proof of deterministic filename + persistence: `test_hitl_persistence.py` (writes `{dataset_key}.json` based on dataset path); directory evidence: `agent_system/src/agents/analysis/reportDemo/metadata/` contains stable per-dataset JSON + generated reports/plots. |
| NFR4 | Safety controls for tool execution at the file-system boundary. | High | Central tool-call policy: path validation, forced output directory, argument caps; prompt-injection scoring (warning). | `agent_system/src/agents/analysis/pipeline/security_guards.py`, enforced in `runner.py` | Unit tests: `test_security_guards.py`; security warnings summarized in `agent_system/src/agents/analysis/helpers/reportWriting/summary.md` and visualized in `e2_guardrails_reliability_summary.png`. |
| NFR5 | Observability: record warnings/errors and basic telemetry per run for debugging and reporting. | High | Persist warnings/errors/telemetry into run metadata; aggregate into metrics and charts. | pipeline state + metadata persistence + harness | Aggregated evidence: `agent_system/src/agents/analysis/helpers/reportWriting/summary.md`, `metrics.csv`, and charts; raw evidence: per-dataset JSON under `agent_system/src/agents/analysis/reportDemo/metadata/`; persistence regression: `test_hitl_persistence.py`; guardrail warning production verified by `test_security_guards.py`. |

## 4.4 Verification summary

Verification in this project uses a combination of:

- **Automated tests** (e.g., HITL persistence, guardrail path/output policies)
- **Auditable metadata** (per-run JSON records)
- **Aggregated evaluation artifacts** (CSV and charts generated from run metadata)

In later sections:

- Section 9 (Tests & Experiments) expands the test matrix and presents quantitative results.
- Section 10 (Security Features) details threat model, controls, and security experiment evidence.
