# 13) References

This section lists conceptual and library references used by the E2 Analysis Agent implementation.

## Core agent frameworks

- **LangGraph** — graphs, nodes, interrupts/resume, and streaming primitives: https://langchain-ai.github.io/langgraph/
- **LangChain (Core + Integrations)** — model/tool abstractions and provider adapters: https://python.langchain.com/docs/

## Agent-to-Agent protocol + service runtime

- **a2a-sdk** — A2A task lifecycle and streaming updates used by the analysis service: https://pypi.org/project/a2a-sdk/
- **FastAPI** — HTTP service layer: https://fastapi.tiangolo.com/
- **Uvicorn** — ASGI server used for local hosting: https://www.uvicorn.org/

## MCP tooling

- **FastMCP** — MCP server framework used to expose analysis/data-processing tools over stdio: https://pypi.org/project/fastmcp/
- **langchain-mcp-adapters** — MCP tool discovery and conversion to LangChain tools: https://pypi.org/project/langchain-mcp-adapters/

## Supporting libraries

- **Pydantic** — typed configuration and schemas: https://docs.pydantic.dev/
- **httpx** — HTTP client utilities (where used): https://www.python-httpx.org/
- **pandas / numpy / scipy / scikit-learn** — data processing and statistical/ML routines (used by tools):
  - https://pandas.pydata.org/
  - https://numpy.org/
  - https://scipy.org/
  - https://scikit-learn.org/
- **matplotlib / seaborn** — charting used for evaluation artifacts: https://matplotlib.org/ , https://seaborn.pydata.org/

## Local LLM runtime (optional)

- **llama-cpp-python** — local GGUF model runtime option used in development tooling: https://pypi.org/project/llama-cpp-python/
