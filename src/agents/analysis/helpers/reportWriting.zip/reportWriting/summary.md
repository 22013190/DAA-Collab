# E2 (A2) Metrics Summary

This folder contains aggregated run metadata (not model internals).


## What the metrics mean

- **kind**: suite label used for grouping (capability vs security).
- **tool_calls**: number of tool calls recorded for the run (proxy for tool-using behavior).
- **tool_errors**: count of tool execution errors recorded.
- **warnings_count / errors_count**: how many warnings/errors the pipeline recorded.
- **security_blocked**: 1 if a warning indicates a tool-call was blocked by security policy, else 0.
- **injection_detected**: 1 if a warning indicates prompt-injection risk detected, else 0.

## Sample sizes

- Total runs aggregated: **7** (unique prompts: **6**)
- capability: **6** (unique prompts: **5**)
- security: **1** (unique prompts: **1**)

## Repeated prompts (diagnostic)

When the same dataset+instruction is run multiple times (or undergoes reflection/retries), the harness counts each as a run.
- **capability**: repeated **2x** on `agent_system/traffic_accidents_cleaned.csv` — Goal: extract structured information from narrative text and show it improves analysis.If a narrative/description column exists, extract at ...

## Guardrails & reliability (counts and rates)

- **capability** (n=6): blocked 0/6 (0%), injection 0/6 (0%), tool-error-any 4/6 (67%), tool-error-rate-per-call 4/41 (10%), run-error-any 1/6 (17%)
- **security** (n=1): blocked 0/1 (0%), injection 1/1 (100%), tool-error-any 0/1 (0%), tool-error-rate-per-call 0/5 (0%), run-error-any 0/1 (0%)

## Tool usage (tool_calls)

- **capability**: mean=6.83, median=5, min=1, max=15
- **security**: mean=5.00, median=5, min=5, max=5

## Notes

- Tool call counts were estimated for **2/7** runs (because some metadata records lacked telemetry).
- Tool error counts were estimated for **3/7** runs (derived from textual error messages when telemetry was missing).
- All-zero **security_blocked** does **not** automatically mean guardrails are broken; it often means the run never attempted a blocked tool call, or the run set didn’t include strong security probes.
- For stronger evidence, run the harness in runner mode so you know exactly which 2–3 security probes were executed.
