# 7) Streaming & HITL (Operational Behavior)

This section explains how the analysis agent remains operable during long-running analysis: it streams progress updates to the client, it emits artifacts incrementally as they are discovered, and it supports a human-in-the-loop (HITL) pause/resume workflow using LangGraph interrupts surfaced through A2A task states.

The key design choice is that streaming is treated as a transport/UI concern, not a LangGraph state concern. The pipeline’s state is reserved for reasoning outputs (plan, tool transcript, insights, artifacts), while the A2A service layer consumes LangGraph streaming and forwards it as A2A task events. This separation keeps the graph state bounded, avoids reducer/concurrency conflicts, and makes the streaming loop testable.

## 7.1 What Is Streamed (A2A Contract A Snapshots)

When streaming is enabled, the service consumes the pipeline’s stream (`stream_mode=["values","updates","messages","custom"]`) and converts it into A2A status updates and artifact updates.

A2A status updates are sent as Contract A “snapshot” payloads: the `content` field contains the *accumulated text so far* (not deltas). This makes polling-friendly clients robust because they can display the latest snapshot without needing to replay prior stream chunks.

In practice, the streamed status message contains four key fields:

- `content`: accumulated status text (sanitized).
- `current_action`: a short label derived from the current node/tool event (e.g., planning, executing tools, synthesizing).
- `current_node`: LangGraph node name when available.
- `tool_call_chunks`: passed through when present on streamed message chunks.

## 7.2 Throttling and Output Hygiene (Why It Doesn’t Flood)

Streaming token-by-token is both noisy for users and expensive for the A2A task update channel. The service therefore applies two levels of hygiene before emitting an update.

First, it sanitizes model output for operational stability. Incremental message content is stripped of model “think blocks” and then ASCII-sanitized to prevent Windows console encoding errors.

Second, it throttles emissions using a combined time-and-size policy:

- A `StatusAccumulator` keeps an accumulated buffer with a hard maximum size (dropping the oldest text past a cap).
- A `StreamThrottle` emits only if either (a) a minimum time interval has passed, or (b) the accumulated output grew by at least a minimum number of characters.

These utilities live in `agent_system/src/agents/analysis/pipeline/streaming_utils.py` and are deliberately transport-layer pure (no A2A SDK dependencies and no LangGraph state mutation).

## 7.3 Artifact Streaming (Incremental Outputs)

Artifacts are emitted in two ways.

During execution, the service inspects `updates` stream chunks and looks for an `artifact_log` list on node outputs. When a new path is observed, it emits an A2A artifact event (`ongoing_artifact`) containing that path as a stable payload. A local `seen_artifact_paths` set prevents re-emitting the same artifact repeatedly.

At completion, the service emits a final `completed_artifact` containing the final report text (as both a schema-stable DataPart and a human-readable TextPart), and then transitions the task to `completed`.

## 7.4 HITL Plan Review (Pause at input-required)

HITL is implemented as a plan-review gate. Conceptually, the pipeline produces a proposed plan and then pauses *before any tools are executed*. This yields high leverage governance: a human can correct direction early, reduce unnecessary tool calls, and prevent unsafe or wasteful actions.

Technically, the planner node calls LangGraph’s `interrupt(payload)` with a JSON-serializable payload describing the plan (and related metadata). When the graph interrupts, LangGraph surfaces an `__interrupt__` field into the stream. The A2A service layer detects this interrupt and does three things atomically:

1) Emit a structured `plan_review` artifact containing the payload.
2) Transition the A2A task into `input-required` by calling `TaskUpdater.requires_input(final=False)`.
3) Return early from the streaming loop (the task is paused, not completed).

The service also attaches a human-readable hint message explaining the acceptable decisions: APPROVE, REVISE with feedback, or ABORT.

## 7.5 Resume Semantics (Same contextId/taskId + hitl_resume DataPart)

Resuming a paused task requires continuity identifiers and a structured decision payload.

- Continuity identifiers: the resume message must include the same `contextId` and `taskId` so the A2A server routes the message to the paused task.
- Decision payload: the client should send a DataPart containing `{"hitl_resume": {"decision": "approve|revise|abort", "feedback": "..."}}`.

On the server side, the service also includes a small robustness feature: if it detects that a request is a resume (the current task is `input_required`) but no `hitl_resume` payload is present, it attempts to infer a decision from the user’s text (e.g., bare “approve”, or longer text treated as revision feedback).

### Snippet: client resume payload (DataPart)

The helper client builds a resume message payload as follows:

```python
def _build_resume_message_payload(*, context_id: str, task_id: str, user_text: str) -> dict[str, Any]:
    decision, feedback = _parse_hitl_reply(user_text)
    return {
        "message": {
            "role": "user",
            "contextId": context_id,
            "taskId": task_id,
            "parts": [
                {
                    "kind": "data",
                    "data": {
                        "hitl_resume": {
                            "decision": decision,
                            "feedback": feedback,
                        }
                    },
                }
            ],
            "messageId": uuid4().hex,
        }
    }
```

This snippet is from `agent_system/src/agents/analysis/helpers/a2a_client.py`.

## 7.6 Figure C: Pause/Resume Sequence (A2A + LangGraph)

The following sequence diagram shows the operational behavior from the client perspective.

```mermaid
sequenceDiagram
    autonumber
    participant C as Client
    participant S as A2A Analysis Service
    participant P as LangGraph Pipeline

    C->>S: SendMessage (dataset_path + instruction)
    S->>P: astream(graph_input=AnalysisPipelineState, thread_id=contextId)
    loop Streaming
        P-->>S: (messages/updates/custom)
        S-->>C: update_status(TaskState.working, snapshot)
        S-->>C: add_artifact(ongoing_artifact) when artifact_log grows
    end

    P-->>S: __interrupt__ (plan_review payload)
    S-->>C: add_artifact(name=plan_review, payload)
    S-->>C: requires_input(TaskState.input_required)

    C->>S: SendMessage resume (same contextId+taskId, DataPart hitl_resume)
    S->>P: astream(graph_input=Command(resume=hitl_resume), thread_id=contextId)

    P-->>S: final output updates (report_text/artifacts)
    S-->>C: add_artifact(name=completed_artifact)
    S-->>C: complete(TaskState.completed)
```

## 7.7 Acceptance Checklist Mapping

The design satisfies the Section 7 acceptance criteria:

- The reader can see why clients receive `input-required`: it is the A2A surface of a LangGraph interrupt.
- The reader can see how continuation works: same `contextId`/`taskId`, plus `hitl_resume` decision payload.
- Streaming is controllable and robust: output is sanitized, throttled, and snapshot-based.

**Evidence pointers**

- Streaming + interrupt handling: `agent_system/src/agents/analysis/a2a_compliant_service.py`
- Throttle/sanitization utilities: `agent_system/src/agents/analysis/pipeline/streaming_utils.py`
- Client resume payload: `agent_system/src/agents/analysis/helpers/a2a_client.py`
- Implementation plan / rationale: `agent_system/src/agents/analysis/pipeline/STREAMING_AND_HITL_PLAN.md`

## 7.8 A2A Agent Card and Server Bootstrap (Discovery, Skills, Task Wiring)

In addition to the streaming loop described above, the analysis agent is packaged as an A2A-compliant HTTP service using the official A2A SDK. This section documents the service-level A2A implementation that enables agent discovery, capability advertisement, and task lifecycle management.

### 7.8.1 Agent discovery and the Agent Card

The service builds an `AgentCard` and serves it through the A2A Starlette application. This is the mechanism A2A clients use for discovery and capability negotiation.

Key advertised fields:

- `name`, `description`, `version`, `url`: identify the agent and provide a stable discovery URL.
- `capabilities.streaming=True`: indicates the service supports streaming task updates.
- `skills`: a list of `AgentSkill` entries that describe major supported analysis modes (e.g., statistical analysis, temporal analysis, pattern detection, visualization).
- `default_input_modes` / `default_output_modes`: set to `text/plain` for broad client compatibility.

Operationally, the service prints the Agent Card endpoint on startup (the well-known card path is provided by the A2A server app).

### 7.8.2 Server wiring (executor, task store, push sender)

The A2A SDK service is composed using the standard tutorial pattern:

- `A2AAnalysisAgentExecutor`: contains the business logic (including the streaming loop, interrupt detection, and resume heuristics).
- `DefaultRequestHandler`: binds the executor to request handling.
- `InMemoryTaskStore`: stores task state in-process for this deployment mode.
- `PushNotificationSender`: implemented as a simple no-op logger (`SimplePushNotificationSender`) to satisfy SDK wiring while keeping the deployment minimal.
- `A2AStarletteApplication`: serves HTTP routes for A2A messaging and agent card discovery.

This wiring establishes the A2A task lifecycle transitions used in earlier subsections (`submit` -> `start_work` -> periodic `update_status`/`add_artifact` -> `requires_input` or `complete`).

### 7.8.3 Message normalization (typed Parts + readable TextPart)

The service preserves the incoming `Message.parts` from the client (so structured `DataPart` payloads survive intact) and then appends a human-readable `TextPart` summary in the canonical format:

```
Dataset: ...
Instructions: ...
Session ID: ...
```

This dual representation is intentional:

- Typed `DataPart` enables programmatic clients (dataset path, HITL resume payload).
- The summary `TextPart` provides a reliable fallback parse surface and improves debuggability for manual clients.

If the incoming text already contains `Dataset:` and `Instructions:`, the service avoids appending a duplicate summary to reduce redundancy.

**Evidence pointers**

- A2A Agent Card + skills + server bootstrap: `agent_system/src/agents/analysis/a2a_compliant_service.py` (`create_a2a_server`, `AgentCard`, `AgentSkill`, `A2AStarletteApplication`)
- Request/parts normalization and HITL resume heuristics: `agent_system/src/agents/analysis/a2a_compliant_service.py` (`execute`)
